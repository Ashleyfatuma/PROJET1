<?php
session_start();

function is_logged_in() {
    return isset($_SESSION['user']);
}

function require_login() {
    if (!is_logged_in()) {
        header('Location: /login.php');
        exit;
    }
}

function require_role($role) {
    require_login();
    if ($_SESSION['user']['role'] !== $role) {
        // Optionnel : tu peux aussi rediriger vers une page d'erreur ou dashboard
        header('HTTP/1.1 403 Forbidden');
        echo "Accès refusé : vous n'avez pas les droits nécessaires.";
        exit;
    }
}

// Pour autoriser plusieurs rôles simultanément
function require_roles(array $roles) {
    require_login();
    if (!in_array($_SESSION['user']['role'], $roles)) {
        header('HTTP/1.1 403 Forbidden');
        echo "Accès refusé : vous n'avez pas les droits nécessaires.";
        exit;
    }
}
