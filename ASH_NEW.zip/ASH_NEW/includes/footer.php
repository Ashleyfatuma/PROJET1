

<footer class="bg-light text-center text-muted py-3 border-top mt-auto">
    <div class="container">
        <p class="mb-0">© <?= date('Y') ?> - Système de Gestion des Déclarations de Naissance. Tous droits réservés.</p>
    </div>
</footer>

<script src="/assets/bootstrap/js/bootstrap.bundle.min.js"></script>
</body>
</html>
