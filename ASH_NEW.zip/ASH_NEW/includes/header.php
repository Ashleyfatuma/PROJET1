<?php
if (!isset($_SESSION)) {
    session_start();
}
$user = isset($_SESSION['user']) ? $_SESSION['user'] : null;
?>
<style>
    html, body {
    height: 100%;
    margin: 0;
}

body {
    display: flex;
    flex-direction: column;
    min-height: 100vh;
}

main {
    flex: 1;
}

</style>

<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
    <div class="container">
        <a class="navbar-brand fw-bold" href="/index.php">Gestion Naissances</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
            aria-controls="navbarNav" aria-expanded="false" aria-label="Afficher la navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav me-auto">
                <?php if ($user): ?>
                    <?php if ($user['role'] === 'admin'): ?>
                        <li class="nav-item"><a class="nav-link" href="dashboard.php">Tableau de bord</a></li>
                        <li class="nav-item"><a class="nav-link" href="manage_users.php">Utilisateurs</a></li>
                        <li class="nav-item"><a class="nav-link" href="manage_hopitaux.php">Hôpitaux</a></li>
                        <li class="nav-item"><a class="nav-link" href="manage_communes.php">Communes</a></li>

                    <?php elseif ($user['role'] === 'agent'): ?>
                        <li class="nav-item"><a class="nav-link" href="dashboard.php">Tableau de bord</a></li>
                        <li class="nav-item"><a class="nav-link" href="naissances.php">Voir les Naissances</a></li>

                    <?php elseif ($user['role'] === 'sagefemme'): ?>
                        <li class="nav-item"><a class="nav-link" href="dashboard.php">Mes Déclarations</a></li>
                        <li class="nav-item"><a class="nav-link" href="ajouter_naissance.php">Nouvelle Naissance</a></li>
                    <?php endif; ?>
                <?php endif; ?>
            </ul>

            <ul class="navbar-nav">
                <?php if ($user): ?>
                    <li class="nav-item">
                        <a class="nav-link fw-bold text-white"  style="margin-left: -190px;">👤 <?= htmlspecialchars($user['prenom']) ?></a>
                    </li>
                    
                <?php else: ?>
                    <li class="nav-item"><a class="nav-link text-white" href="/login.php">Connexion</a></li>
                    <li class="nav-item"><a class="nav-link text-white" href="/register.php">Inscription</a></li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>
