<?php
session_start();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Accueil - Gestion des Naissances</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<?php include 'includes/header.php'; ?>

<div class="container mt-5">
    <div class="row align-items-center">
        <div class="col-md-6">
            <h1 class="display-5 fw-bold">Système de Gestion des Naissances</h1>
            <p class="lead">Une solution numérique pour faciliter la déclaration, la validation et la gestion des naissances dans les hôpitaux et les communes.</p>
            <?php if (!isset($_SESSION['user'])): ?>
                <a href="login.php" class="btn btn-primary btn-lg me-2">Connexion</a>
                <a href="register.php" class="btn btn-outline-secondary btn-lg">Inscription</a>
            <?php else: ?>
                <?php
                    $role = $_SESSION['user']['role'];
                    $dashboard = "pages/$role/dashboard.php";
                ?>
                <a href="<?= $dashboard ?>" class="btn btn-success btn-lg">Tableau de bord</a>
            <?php endif; ?>
        </div>
        <div class="col-md-6 text-center">
            <img src="assets/img/logo.png" alt="Naissance" class="img-fluid" style="max-height: 300px;">
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
</body>
</html>
