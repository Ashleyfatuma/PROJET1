<?php
session_start();
require 'config.php';

$message = '';

// Si formulaire soumis
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nom = trim($_POST['nom']);
    $post_nom = trim($_POST['post_nom']);
    $prenom = trim($_POST['prenom']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $role = $_POST['role'];

    // Validation simple
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $message = "Adresse email invalide.";
    } elseif (strlen($password) < 6) {
        $message = "Le mot de passe doit contenir au moins 6 caractères.";
    } elseif (empty($nom) || empty($post_nom) || empty($prenom) || empty($role)) {
        $message = "Veuillez remplir tous les champs.";
    } else {
        // Vérifier si l'email est déjà utilisé
        $check = $pdo->prepare("SELECT id FROM users WHERE email = ?");
        $check->execute(array($email));
        if ($check->rowCount() > 0) {
            $message = "Cet email est déjà enregistré.";
        } else {
            $hashed_password = $password;
            $stmt = $pdo->prepare("INSERT INTO users (nom, post_nom, prenom, email, password, role) VALUES (?, ?, ?, ?, ?, ?)");
            try {
                $stmt->execute(array($nom, $post_nom, $prenom, $email, $hashed_password, $role));
                $message = "Inscription réussie. Vous pouvez maintenant vous connecter.";
            } catch (PDOException $e) {
                $message = "Erreur lors de l'inscription : " . $e->getMessage();
            }
        }
    }
}

include 'includes/header.php';
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Connexion - Gestion des Naissances</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>


<div class="row justify-content-center">
    <div class="col-md-6">
        <div class="card shadow">
            <div class="card-header bg-success text-white text-center">
                <h4>Créer un compte</h4>
            </div>
            <div class="card-body">
                <?php if ($message): ?>
                    <div class="alert alert-info"><?= htmlspecialchars($message) ?></div>
                <?php endif; ?>
                <form method="post" novalidate>
                    <div class="mb-3">
                        <label>Nom</label>
                        <input class="form-control" name="nom" required>
                    </div>
                    <div class="mb-3">
                        <label>Post-nom</label>
                        <input class="form-control" name="post_nom" required>
                    </div>
                    <div class="mb-3">
                        <label>Prénom</label>
                        <input class="form-control" name="prenom" required>
                    </div>
                    <div class="mb-3">
                        <label>Email</label>
                        <input class="form-control" type="email" name="email" required>
                    </div>
                    <div class="mb-3">
                        <label>Mot de passe</label>
                        <input class="form-control" type="password" name="password" required>
                    </div>
                    <div class="mb-3">
                        <label>Rôle</label>
                        <select class="form-select" name="role" required>
                            <option value="">Choisir un rôle</option>
                            <option value="sagefemme">Sage-femme</option>
                            <option value="agent">Agent</option>
                        </select>
                    </div>
                    <button class="btn btn-success w-100">S'inscrire</button>
                </form>
                <div class="text-center mt-3">
                    <small>Déjà inscrit ? <a href="login.php">Se connecter</a></small>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
