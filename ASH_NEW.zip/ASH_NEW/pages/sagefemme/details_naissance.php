<?php

require_once '../../includes/auth.php';
require_once '../../config.php';

require_login();

// Seulement agent
require_role('sagefemme');

// Plusieurs rôles autorisés (exemple : admin ou agent)
//require_roles(['admin', 'agent','sagefemme']);

if (!isset($_GET['id']) || empty($_GET['id'])) {
    echo "ID de naissance manquant.";
    exit;
}

$id = $_GET['id'];
$user_id = $_SESSION['user']['id'];

$stmt = $pdo->prepare("SELECT n.*, h.nom AS hopital_nom FROM naissances n
                       LEFT JOIN hopitaux h ON n.hopital_id = h.id
                       WHERE n.id = ? AND n.sagefemme_id = ?");
$stmt->execute([$id, $user_id]);
$naissance = $stmt->fetch();

if (!$naissance) {
    echo "Naissance introuvable ou accès refusé.";
    exit;
}


?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Connexion - Gestion des Naissances</title>
    <link rel="stylesheet" href="../../assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="../../assets/css/style.css">
</head>
<body>
<?php 
include '../../includes/header.php';
?>
<ul class="navbar-nav" style="margin-left:87%;margin-top:-53px; position: relative;">
    <li class="nav-item">
        <a class="nav-link text-white" href="../../logout.php">Se déconnecter</a>
    </li>
</ul>
<main class="container py-4">
<div class="container py-4">
    <h2 class="mb-4">Détails de la déclaration de naissance</h2>

    <div class="card shadow-sm">
        <div class="card-body">
            <table class="table table-bordered mb-0">
                <tbody>
                    <tr>
                        <th>Nom de l'enfant</th>
                        <td><?= htmlspecialchars($naissance['nom_enfant']) ?></td>
                    </tr>
                    <tr>
                        <th>Post-nom</th>
                        <td><?= htmlspecialchars($naissance['post_nom_enfant']) ?></td>
                    </tr>
                    <tr>
                        <th>Prénom</th>
                        <td><?= htmlspecialchars($naissance['prenom_enfant']) ?></td>
                    </tr>
                    <tr>
                        <th>Sexe</th>
                        <td><?= htmlspecialchars($naissance['sexe']) ?></td>
                    </tr>
                    <tr>
                        <th>Date de naissance</th>
                        <td><?= htmlspecialchars($naissance['date_naissance']) ?></td>
                    </tr>
                    <tr>
                        <th>Heure de naissance</th>
                        <td><?= htmlspecialchars($naissance['heure_naissance']) ?></td>
                    </tr>
                    <tr>
                        <th>Nom du père</th>
                        <td><?= htmlspecialchars($naissance['pere_nom']) ?></td>
                    </tr>
                    <tr>
                        <th>Nom de la mère</th>
                        <td><?= htmlspecialchars($naissance['mere_nom']) ?></td>
                    </tr>
                    <tr>
                        <th>Hôpital</th>
                        <td><?= htmlspecialchars($naissance['hopital_nom'] ?? 'Non spécifié') ?></td>
                    </tr>
                    <tr>
                        <th>Statut</th>
                        <td>
                            <?php
                            $status = $naissance['statut'];
                            $badgeClass = match ($status) {
                                'en_attente' => 'bg-warning text-dark',
                                'valide' => 'bg-success',
                                'rejete' => 'bg-danger',
                                default => 'bg-secondary'
                            };
                            ?>
                            <span class="badge <?= $badgeClass ?>"><?= htmlspecialchars(ucfirst($status)) ?></span>
                        </td>
                    </tr>
                    <tr>
                        <th>Observations</th>
                        <td><?= nl2br(htmlspecialchars($naissance['observations'])) ?></td>
                    </tr>
                </tbody>
            </table>

            <a href="dashboard.php" class="btn btn-secondary mt-3">Retour au tableau de bord</a>
        </div>
    </div>
</div>

                        </main>

<?php include '../../includes/footer.php'; ?>
