<?php

require_once '../../includes/auth.php';
require_once '../../config.php';

require_login();

// Seulement agent
require_role('sagefemme');

// Plusieurs rôles autorisés (exemple : admin ou agent)


$sagefemme_id = $_SESSION['user']['id'];
$message = '';

// Vérifier que l'ID est passé en GET
if (!isset($_GET['id'])) {
    echo "ID de naissance manquant.";
    exit;
}

$id = $_GET['id'];

// Récupérer la déclaration de naissance pour cette sage-femme
$stmt = $pdo->prepare("SELECT * FROM naissances WHERE id = ? AND sagefemme_id = ?");
$stmt->execute([$id, $sagefemme_id]);
$naissance = $stmt->fetch();

if (!$naissance) {
    echo "Naissance introuvable ou accès interdit.";
    exit;
}

// Vérifier que le statut est "en_attente"
if ($naissance['statut'] !== 'en_attente') {
    echo "La naissance ne peut pas être modifiée car elle est déjà traitée.";
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nom_enfant = trim($_POST['nom_enfant'] ?? '');
    $post_nom_enfant = trim($_POST['post_nom_enfant'] ?? '');
    $prenom_enfant = trim($_POST['prenom_enfant'] ?? '');
    $sexe = $_POST['sexe'] ?? '';
    $date_naissance = $_POST['date_naissance'] ?? '';
    $heure_naissance = $_POST['heure_naissance'] ?? '';
    $pere_nom = trim($_POST['pere_nom'] ?? '');
    $mere_nom = trim($_POST['mere_nom'] ?? '');
    $observations = trim($_POST['observations'] ?? '');

    if ($nom_enfant && $post_nom_enfant && $prenom_enfant && $sexe && $date_naissance && $heure_naissance && $pere_nom && $mere_nom) {
        $stmt = $pdo->prepare("UPDATE naissances SET 
            nom_enfant = ?, post_nom_enfant = ?, prenom_enfant = ?, sexe = ?, 
            date_naissance = ?, heure_naissance = ?, pere_nom = ?, mere_nom = ?, observations = ?
            WHERE id = ? AND sagefemme_id = ?");

        try {
            $stmt->execute([
                $nom_enfant, $post_nom_enfant, $prenom_enfant, $sexe,
                $date_naissance, $heure_naissance, $pere_nom, $mere_nom, $observations,
                $id, $sagefemme_id
            ]);
            $message = "Déclaration mise à jour avec succès.";

            // Recharger les données modifiées
            $stmt = $pdo->prepare("SELECT * FROM naissances WHERE id = ? AND sagefemme_id = ?");
            $stmt->execute([$id, $sagefemme_id]);
            $naissance = $stmt->fetch();
        } catch (Exception $e) {
            $message = "Erreur lors de la mise à jour : " . $e->getMessage();
        }
    } else {
        $message = "Veuillez remplir tous les champs obligatoires.";
    }
}

?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Connexion - Gestion des Naissances</title>
    <link rel="stylesheet" href="../../assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="../../assets/css/style.css">
</head>
<body>

<?php 
include '../../includes/header.php';
?>
<ul class="navbar-nav" style="margin-left:87%;margin-top:-53px; position: relative;">
    <li class="nav-item">
        <a class="nav-link text-white" href="../../logout.php">Se déconnecter</a>
    </li>
</ul>
<main class="container py-4">
<div class="container py-4">
    <h2 class="mb-4">Modifier la déclaration de naissance</h2>

    <?php if ($message): ?>
        <div class="alert alert-info"><?= htmlspecialchars($message) ?></div>
    <?php endif; ?>

    <form method="post" class="needs-validation" novalidate>
        <div class="row g-3">
            <div class="col-md-4">
                <label for="nom_enfant" class="form-label">Nom <span class="text-danger">*</span></label>
                <input type="text" id="nom_enfant" name="nom_enfant" class="form-control" required
                       value="<?= htmlspecialchars($_POST['nom_enfant'] ?? $naissance['nom_enfant']) ?>">
                <div class="invalid-feedback">Ce champ est obligatoire.</div>
            </div>

            <div class="col-md-4">
                <label for="post_nom_enfant" class="form-label">Post-nom <span class="text-danger">*</span></label>
                <input type="text" id="post_nom_enfant" name="post_nom_enfant" class="form-control" required
                       value="<?= htmlspecialchars($_POST['post_nom_enfant'] ?? $naissance['post_nom_enfant']) ?>">
                <div class="invalid-feedback">Ce champ est obligatoire.</div>
            </div>

            <div class="col-md-4">
                <label for="prenom_enfant" class="form-label">Prénom <span class="text-danger">*</span></label>
                <input type="text" id="prenom_enfant" name="prenom_enfant" class="form-control" required
                       value="<?= htmlspecialchars($_POST['prenom_enfant'] ?? $naissance['prenom_enfant']) ?>">
                <div class="invalid-feedback">Ce champ est obligatoire.</div>
            </div>

            <div class="col-md-3">
                <label for="sexe" class="form-label">Sexe <span class="text-danger">*</span></label>
                <select id="sexe" name="sexe" class="form-select" required>
                    <option value="">-- Sélectionner --</option>
                    <option value="Masculin" <?= (($_POST['sexe'] ?? $naissance['sexe']) === 'Masculin') ? 'selected' : '' ?>>Masculin</option>
                    <option value="Féminin" <?= (($_POST['sexe'] ?? $naissance['sexe']) === 'Féminin') ? 'selected' : '' ?>>Féminin</option>
                </select>
                <div class="invalid-feedback">Veuillez sélectionner un sexe.</div>
            </div>

            <div class="col-md-3">
                <label for="date_naissance" class="form-label">Date de naissance <span class="text-danger">*</span></label>
                <input type="date" id="date_naissance" name="date_naissance" class="form-control" required
                       value="<?= htmlspecialchars($_POST['date_naissance'] ?? $naissance['date_naissance']) ?>">
                <div class="invalid-feedback">Veuillez fournir une date.</div>
            </div>

            <div class="col-md-3">
                <label for="heure_naissance" class="form-label">Heure de naissance <span class="text-danger">*</span></label>
                <input type="time" id="heure_naissance" name="heure_naissance" class="form-control" required
                       value="<?= htmlspecialchars($_POST['heure_naissance'] ?? $naissance['heure_naissance']) ?>">
                <div class="invalid-feedback">Veuillez fournir une heure.</div>
            </div>

            <div class="col-md-3"></div>

            <div class="col-md-6">
                <label for="pere_nom" class="form-label">Nom du père <span class="text-danger">*</span></label>
                <input type="text" id="pere_nom" name="pere_nom" class="form-control" required
                       value="<?= htmlspecialchars($_POST['pere_nom'] ?? $naissance['pere_nom']) ?>">
                <div class="invalid-feedback">Ce champ est obligatoire.</div>
            </div>

            <div class="col-md-6">
                <label for="mere_nom" class="form-label">Nom de la mère <span class="text-danger">*</span></label>
                <input type="text" id="mere_nom" name="mere_nom" class="form-control" required
                       value="<?= htmlspecialchars($_POST['mere_nom'] ?? $naissance['mere_nom']) ?>">
                <div class="invalid-feedback">Ce champ est obligatoire.</div>
            </div>

            <div class="col-12">
                <label for="observations" class="form-label">Observations</label>
                <textarea id="observations" name="observations" class="form-control" rows="3"><?= htmlspecialchars($_POST['observations'] ?? $naissance['observations']) ?></textarea>
            </div>

            <div class="col-12">
                <button type="submit" class="btn btn-primary">Enregistrer les modifications</button>
                <a href="dashboard.php" class="btn btn-secondary ms-2">Annuler</a>
            </div>
        </div>
    </form>
</div>

<script>
// Bootstrap 5 form validation
(() => {
  'use strict';
  const forms = document.querySelectorAll('.needs-validation');
  Array.from(forms).forEach(form => {
    form.addEventListener('submit', event => {
      if (!form.checkValidity()) {
        event.preventDefault();
        event.stopPropagation();
      }
      form.classList.add('was-validated');
    }, false);
  });
})();
</script>

<?php include '../../includes/footer.php'; ?>
