<?php
session_start();
require_once '../../includes/auth.php';
require_once '../../config.php';

require_login();

// Seulement agent
require_role('sagefemme');

// Plusieurs rôles autorisés (exemple : admin ou agent)
require_roles(['admin', 'agent','sagefemme']);

$user_id = $_SESSION['user']['id'];
$stmt = $pdo->prepare("SELECT * FROM naissances WHERE sagefemme_id = ? ORDER BY date_declaration DESC");
$stmt->execute([$user_id]);
$naissances = $stmt->fetchAll();

include '../../includes/header.php';
?>
<ul class="navbar-nav" style="margin-left:87%;margin-top:-53px; position: relative;">
    <li class="nav-item">
        <a class="nav-link text-white" href="../../logout.php">Se déconnecter</a>
    </li>
</ul>
<main class="container py-4">
<div class="container py-4">
    <h2 class="mb-4">Mes déclarations de naissance</h2>

    <?php if (empty($naissances)): ?>
        <div class="alert alert-info">Vous n'avez encore déclaré aucune naissance.</div>
    <?php else: ?>
        <div class="table-responsive">
            <table class="table table-striped table-hover align-middle">
                <thead class="table-dark">
                    <tr>
                        <th>Nom enfant</th>
                        <th>Date de naissance</th>
                        <th>Statut</th>
                        <th>Détails</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($naissances as $n): ?>
                        <?php
                            $status = $n['statut'];
                            $badgeClass = match ($status) {
                                'en_attente' => 'bg-warning text-dark',
                                'valide' => 'bg-success',
                                'rejete' => 'bg-danger',
                                default => 'bg-secondary'
                            };
                        ?>
                        <tr>
                            <td><?= htmlspecialchars($n['nom_enfant'] . ' ' . $n['post_nom_enfant'] . ' ' . $n['prenom_enfant']) ?></td>
                            <td><?= htmlspecialchars($n['date_naissance']) ?></td>
                            <td><span class="badge <?= $badgeClass ?>"><?= htmlspecialchars(ucfirst($status)) ?></span></td>
                            <td><a href="details_naissance.php?id=<?= $n['id'] ?>" class="btn btn-sm btn-info">Voir</a></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div>

                        </main>

<?php include '../../includes/footer.php'; ?>
