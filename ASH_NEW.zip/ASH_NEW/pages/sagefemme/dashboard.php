<?php
require_once '../../includes/auth.php';
require_once '../../config.php';

// Seulement connecté
require_login();

// Seulement agent
require_role('sagefemme');


$user_id = $_SESSION['user']['id'];
$stmt = $pdo->prepare("SELECT * FROM naissances WHERE sagefemme_id = ? ORDER BY date_declaration DESC");
$stmt->execute([$user_id]);
$naissances = $stmt->fetchAll();



include '../../includes/header.php';
?>

<main class="container py-4">

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Connexion - Gestion des Naissances</title>
    <link rel="stylesheet" href="../../assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="../../assets/css/style.css">
</head>
<body>
<ul class="navbar-nav" style="float:right;margin-top:-72px; position: relative;">
    <li class="nav-item">
        <a class="nav-link text-white" href="../../logout.php">Se déconnecter</a>
    </li>
</ul>
<div class="container py-4">
    <h2 class="mb-4">Tableau de bord - Sage-femme</h2>
    <a href="ajouter_naissance.php" class="btn btn-primary mb-3">Ajouter une naissance</a>

    <?php if (count($naissances) === 0): ?>
        <div class="alert alert-info">Aucune déclaration de naissance trouvée.</div>
    <?php else: ?>
    <div class="table-responsive">
        <table class="table table-bordered table-hover align-middle">
            <thead class="table-dark">
                <tr>
                    <th>Nom de l'enfant</th>
                    <th>Date de naissance</th>
                    <th>Statut</th>
                    <th style="width: 160px;">Actions</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($naissances as $n): ?>
                <tr>
                    <td><?= htmlspecialchars($n['nom_enfant'] . ' ' . $n['post_nom_enfant'] . ' ' . $n['prenom_enfant']) ?></td>
                    <td><?= htmlspecialchars($n['date_naissance']) ?></td>
                    <td><?= htmlspecialchars($n['statut']) ?></td>
                    <td>
                        <a href="details_naissance.php?id=<?= $n['id'] ?>" class="btn btn-sm btn-info me-1 mb-1">Voir</a>
                        <?php if ($n['statut'] === 'en_attente'): ?>
                            <a href="modifier_naissance.php?id=<?= $n['id'] ?>" class="btn btn-sm btn-warning mb-1">Modifier</a>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>
</div>
                        </main>
<?php include '../../includes/footer.php'; ?>
