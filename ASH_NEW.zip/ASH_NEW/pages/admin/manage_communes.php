<?php
require_once '../../includes/auth.php';
require_once '../../config.php';

// Seulement connecté
require_login();

// Seulement admin
require_role('admin');

$message = '';

// Ajout de commune
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nom = trim($_POST['nom'] ?? '');
    if ($nom !== '') {
        $stmt = $pdo->prepare("INSERT INTO communes (nom) VALUES (?)");
        $stmt->execute([$nom]);
        $message = "Commune ajoutée avec succès.";
    } else {
        $message = "Le nom de la commune est obligatoire.";
    }
}

// Suppression par id
if (isset($_GET['delete_id'])) {
    $delete_id = intval($_GET['delete_id']);
    $stmt = $pdo->prepare("DELETE FROM communes WHERE id = ?");
    if ($stmt->execute([$delete_id])) {
        $message = "Commune supprimée.";
    } else {
        $message = "Erreur lors de la suppression.";
    }
}

$communes = $pdo->query("SELECT * FROM communes ORDER BY nom ASC")->fetchAll();


?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Connexion - Gestion des Naissances</title>
    <link rel="stylesheet" href="../../assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="../../assets/css/style.css">
</head>
<body>

<?php 
include '../../includes/header.php';
?>
<ul class="navbar-nav" style="margin-left:87%;margin-top:-53px; position: relative;">
    <li class="nav-item">
        <a class="nav-link text-white" href="../../logout.php">Se déconnecter</a>
    </li>
</ul>
<main class="container py-4">

<div class="container py-4">
    <h2 class="mb-4">Gestion des communes</h2>

    <?php if ($message): ?>
    <div class="alert alert-info"><?= htmlspecialchars($message) ?></div>
    <?php endif; ?>

    <form method="post" class="row g-3 mb-4">
        <div class="col-md-8">
            <input type="text" name="nom" class="form-control" placeholder="Nom de la commune" required>
        </div>
        <div class="col-md-4 d-grid">
            <button type="submit" class="btn btn-primary">Ajouter</button>
        </div>
    </form>

    <table class="table table-bordered table-hover">
        <thead class="table-dark">
            <tr>
                <th>Nom</th>
                <th style="width:120px;">Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($communes as $c): ?>
            <tr>
                <td><?= htmlspecialchars($c['nom']) ?></td>
                <td>
                    <a href="?delete_id=<?= $c['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Supprimer cette commune ?')">
                        Supprimer
                    </a>
                </td>
            </tr>
            <?php endforeach; ?>
            <?php if (empty($communes)): ?>
            <tr><td colspan="2" class="text-center">Aucune commune enregistrée.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
</main>
<?php include '../../includes/footer.php'; ?>
