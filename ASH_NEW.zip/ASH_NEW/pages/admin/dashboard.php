<?php
require_once '../../config.php';
require_once '../../includes/auth.php';

// Seulement connecté
require_login();

// Seulement admin
require_role('admin');


// Récupération de statistiques
$total_users = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
$total_sagefemmes = $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'sagefemme'")->fetchColumn();
$total_agents = $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'agent'")->fetchColumn();
$total_naissances = $pdo->query("SELECT COUNT(*) FROM naissances")->fetchColumn();
$total_hopitaux = $pdo->query("SELECT COUNT(*) FROM hopitaux")->fetchColumn();
$total_communes = $pdo->query("SELECT COUNT(*) FROM communes")->fetchColumn();



?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Connexion - Gestion des Naissances</title>
    <link rel="stylesheet" href="../../assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="../../assets/css/style.css">
</head>
<body>

<?php 
include '../../includes/header.php';
?>
<ul class="navbar-nav" style="margin-left:87%;margin-top:-53px; position: relative;">
    <li class="nav-item">
        <a class="nav-link text-white" href="../../logout.php">Se déconnecter</a>
    </li>
</ul>
<main class="container py-4">

        <div class="container py-4">
            <h2 class="mb-4">Tableau de bord Administrateur</h2>

            <div class="row g-4">
                <div class="col-md-4">
                    <div class="card shadow-sm border-start border-primary border-4">
                        <div class="card-body">
                            <h5 class="card-title">Utilisateurs</h5>
                            <p class="fs-3"><?= $total_users ?></p>
                            <p class="mb-0 text-muted">Dont <?= $total_sagefemmes ?> sages-femmes et <?= $total_agents ?> agents</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card shadow-sm border-start border-success border-4">
                        <div class="card-body">
                            <h5 class="card-title">Naissances déclarées</h5>
                            <p class="fs-3"><?= $total_naissances ?></p>
                            <p class="mb-0 text-muted">Toutes maternités confondues</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card shadow-sm border-start border-warning border-4">
                        <div class="card-body">
                            <h5 class="card-title">Structures</h5>
                            <p class="fs-3"><?= $total_hopitaux ?></p>
                            <p class="mb-0 text-muted">+ <?= $total_communes ?> communes</p>
                        </div>
                    </div>
                </div>
            </div>

            <hr class="my-5">

            <div class="row text-center">
                <div class="col-md-3 mb-3">
                    <a href="manage_users.php" class="btn btn-outline-dark w-100 py-3">
                        👤 Gérer utilisateurs
                    </a>
                </div>
                <div class="col-md-3 mb-3">
                    <a href="manage_hopitaux.php" class="btn btn-outline-dark w-100 py-3">
                        🏥 Gérer hôpitaux
                    </a>
                </div>
                <div class="col-md-3 mb-3">
                    <a href="manage_communes.php" class="btn btn-outline-dark w-100 py-3">
                        🗺️ Gérer communes
                    </a>
                </div>
                <div class="col-md-3 mb-3">
                    <a href="../pages/agent/dashboard.php" class="btn btn-outline-dark w-100 py-3">
                        👁️ Vue agent
                    </a>
                </div>
            </div>
        </div>
</main>
<?php include '../../includes/footer.php'; ?>
