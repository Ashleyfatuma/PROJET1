<?php

require_once '../../includes/auth.php';
require_once '../../config.php';

// Seulement connecté
require_login();

// Seulement admin
require_role('admin');

$message = '';

// Traitement ajout hôpital
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nom = trim($_POST['nom'] ?? '');
    $adresse = trim($_POST['adresse'] ?? '');

    if ($nom !== '') {
        $stmt = $pdo->prepare("INSERT INTO hopitaux (nom, adresse) VALUES (?, ?)");
        $stmt->execute([$nom, $adresse]);
        $message = "Hôpital ajouté avec succès.";
    } else {
        $message = "Le nom de l'hôpital est obligatoire.";
    }
}

// Suppression par id (plus sûr que nom)
if (isset($_GET['delete_id'])) {
    $delete_id = intval($_GET['delete_id']);
    $stmt = $pdo->prepare("DELETE FROM hopitaux WHERE id = ?");
    if ($stmt->execute([$delete_id])) {
        $message = "Hôpital supprimé.";
    } else {
        $message = "Erreur lors de la suppression.";
    }
}

$hopitaux = $pdo->query("SELECT * FROM hopitaux ORDER BY nom ASC")->fetchAll();


?>


<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Connexion - Gestion des Naissances</title>
    <link rel="stylesheet" href="../../assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="../../assets/css/style.css">
</head>
<body>

<?php 
include '../../includes/header.php';
?>
<ul class="navbar-nav" style="margin-left:87%;margin-top:-53px; position: relative;">
    <li class="nav-item">
        <a class="nav-link text-white" href="../../logout.php">Se déconnecter</a>
    </li>
</ul>
<main class="container py-4">

<div class="container py-4">
    <h2 class="mb-4">Gestion des hôpitaux</h2>

    <?php if ($message): ?>
    <div class="alert alert-info"><?= htmlspecialchars($message) ?></div>
    <?php endif; ?>

    <form method="post" class="row g-3 mb-4">
        <div class="col-md-5">
            <input type="text" name="nom" class="form-control" placeholder="Nom de l'hôpital" required>
        </div>
        <div class="col-md-5">
            <input type="text" name="adresse" class="form-control" placeholder="Adresse">
        </div>
        <div class="col-md-2 d-grid">
            <button type="submit" class="btn btn-primary">Ajouter</button>
        </div>
    </form>

    <table class="table table-striped table-hover">
        <thead class="table-dark">
            <tr>
                <th>Nom</th>
                <th>Adresse</th>
                <th style="width:120px;">Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($hopitaux as $h): ?>
            <tr>
                <td><?= htmlspecialchars($h['nom']) ?></td>
                <td><?= htmlspecialchars($h['adresse']) ?></td>
                <td>
                    <a href="?delete_id=<?= $h['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Supprimer cet hôpital ?')">
                        Supprimer
                    </a>
                </td>
            </tr>
            <?php endforeach; ?>
            <?php if (empty($hopitaux)): ?>
            <tr><td colspan="3" class="text-center">Aucun hôpital enregistré.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

</main>

<?php include '../../includes/footer.php'; ?>
