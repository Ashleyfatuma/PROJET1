<?php
require_once '../../includes/auth.php';
require_once '../../config.php';

// Seulement connecté
require_login();

// Seulement admin
require_role('admin');



// Suppression utilisateur
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
    $stmt->execute(array($id));
    header("Location: manage_users.php");
    exit;
}

$users = $pdo->query("SELECT * FROM users ORDER BY created_at DESC")->fetchAll();

?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Connexion - Gestion des Naissances</title>
    <link rel="stylesheet" href="../../assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="../../assets/css/style.css">
</head>
<body>

<?php 
include '../../includes/header.php';
?>
<ul class="navbar-nav" style="margin-left:87%;margin-top:-53px; position: relative;">
    <li class="nav-item">
        <a class="nav-link text-white" href="../../logout.php">Se déconnecter</a>
    </li>
</ul>
<main class="container py-4">
<div class="container py-4">
    <h2 class="mb-4">Gestion des utilisateurs</h2>

    <table class="table table-hover table-bordered align-middle">
        <thead class="table-dark">
            <tr>
                <th>Nom complet</th>
                <th>Email</th>
                <th>Rôle</th>
                <th>Créé le</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($users as $u): ?>
            <tr>
                <td><?= htmlspecialchars("{$u['nom']} {$u['post_nom']} {$u['prenom']}") ?></td>
                <td><?= htmlspecialchars($u['email']) ?></td>
                <td class="text-capitalize"><?= htmlspecialchars($u['role']) ?></td>
                <td><?= htmlspecialchars(date('d/m/Y H:i', strtotime($u['created_at']))) ?></td>
                <td>
                    <a href="?delete=<?= $u['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Supprimer cet utilisateur ?')">
                        Supprimer
                    </a>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
            </main>

<?php include '../../includes/footer.php'; ?>