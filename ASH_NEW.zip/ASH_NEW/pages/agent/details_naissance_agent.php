<?php

require_once '../../includes/auth.php';
require_once '../../config.php';

// Seulement connecté
require_login();

// Seulement agent
require_role('agent');

// Plusieurs rôles autorisés (exemple : admin ou agent)


if (!isset($_GET['id']) || empty($_GET['id'])) {
    echo "ID de naissance manquant.";
    exit;
}

$id = $_GET['id'];

// Récupérer la déclaration de naissance avec infos hospitalières
$stmt = $pdo->prepare("
    SELECT n.*, h.nom AS hopital_nom, u.nom AS sage_nom, u.prenom AS sage_prenom
    FROM naissances n
    LEFT JOIN hopitaux h ON n.hopital_id = h.id
    LEFT JOIN users u ON n.sagefemme_id = u.id
    WHERE n.id = ?
");
$stmt->execute([$id]);
$naissance = $stmt->fetch();

if (!$naissance) {
    echo "Naissance introuvable.";
    exit;
}

?>


<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Connexion - Gestion des Naissances</title>
    <link rel="stylesheet" href="../../assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="../../assets/css/style.css">
</head>
<body>

<?php 
include '../../includes/header.php';
?>
<ul class="navbar-nav" style="margin-left:87%;margin-top:-53px; position: relative;">
    <li class="nav-item">
        <a class="nav-link text-white" href="../../logout.php">Se déconnecter</a>
    </li>
</ul>
<main class="container py-4">

<div class="container py-4">
    <h2 class="mb-4">Détails de la déclaration de naissance</h2>

    <table class="table table-bordered table-striped">
        <tr><th>Nom enfant</th><td><?= htmlspecialchars($naissance['nom_enfant'] . ' ' . $naissance['post_nom_enfant'] . ' ' . $naissance['prenom_enfant']) ?></td></tr>
        <tr><th>Date naissance</th><td><?= htmlspecialchars($naissance['date_naissance']) ?></td></tr>
        <tr><th>Heure naissance</th><td><?= htmlspecialchars($naissance['heure_naissance']) ?></td></tr>
        <tr><th>Sexe</th><td><?= htmlspecialchars($naissance['sexe']) ?></td></tr>
        <tr><th>Père</th><td><?= htmlspecialchars($naissance['pere_nom']) ?></td></tr>
        <tr><th>Mère</th><td><?= htmlspecialchars($naissance['mere_nom']) ?></td></tr>
        <tr><th>Hôpital</th><td><?= htmlspecialchars($naissance['hopital_nom'] ?? 'Non spécifié') ?></td></tr>
        <tr><th>Sage-femme</th><td><?= htmlspecialchars($naissance['sage_nom'] . ' ' . $naissance['sage_prenom']) ?></td></tr>
        <tr><th>Statut</th><td><?= htmlspecialchars($naissance['statut']) ?></td></tr>
        <tr><th>Observations</th><td><?= nl2br(htmlspecialchars($naissance['observations'])) ?></td></tr>
    </table>

    <a href="dashboard.php" class="btn btn-secondary">Retour au tableau de bord</a>
</div>

</main>

<?php include '../../includes/footer.php'; ?>
