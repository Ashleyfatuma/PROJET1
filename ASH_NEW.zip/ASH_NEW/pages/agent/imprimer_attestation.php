<?php
require_once '../../config.php';
require_once '../../includes/auth.php';

require_login();
require_role('agent');

if (!isset($_GET['id'])) {
    die("Naissance non trouvée");
}

$id = intval($_GET['id']);
$stmt = $pdo->prepare("SELECT * FROM naissances WHERE id = ?");
$stmt->execute([$id]);
$naissance = $stmt->fetch();

if (!$naissance) {
    die("Enregistrement introuvable");
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Attestation de Naissance</title>
    <style>
        body { font-family: Arial, sans-serif; padding: 40px; }
        h2 { text-align: center; }
        .section { margin-bottom: 20px; }
        .signature { margin-top: 50px; text-align: right; }
        @media print {
            button { display: none; }
        }
    </style>
</head>
<body>

<button onclick="window.print()">🖨️ Imprimer</button>

<h2>Attestation de Naissance</h2>

<div class="section">
    <strong>Nom de l'enfant :</strong> <?= $naissance['nom_enfant'] ?><br>
    <strong>Date de naissance :</strong> <?= date('d/m/Y', strtotime($naissance['date_naissance'])) ?><br>
    <strong>Sexe :</strong> <?= ucfirst($naissance['sexe']) ?><br>
    <strong>Lieu de naissance :</strong> <?= $naissance['lieu_naissance'] ?>
</div>

<div class="section">
    <strong>Nom du père :</strong> <?= $naissance['nom_pere'] ?><br>
    <strong>Nom de la mère :</strong> <?= $naissance['nom_mere'] ?>
</div>

<div class="signature">
    Fait à <?= $naissance['lieu_naissance'] ?>, le <?= date('d/m/Y') ?><br>
    <br><br>
    ___________________________<br>
    Signature de l’agent
</div>

</body>
</html>
