<?php

require_once '../../includes/auth.php';
require_once '../../config.php';

// Seulement connecté
require_login();

// Seulement agent
require_role('agent');


if (!isset($_GET['id']) || empty($_GET['id'])) {
    echo "ID de naissance manquant.";
    exit;
}

$id = $_GET['id'];
$agent_id = $_SESSION['user']['id'];
$message = '';

// Récupérer la déclaration de naissance en attente
$stmt = $pdo->prepare("SELECT * FROM naissances WHERE id = ? AND statut = 'en_attente'");
$stmt->execute([$id]);
$naissance = $stmt->fetch();

if (!$naissance) {
    echo "Naissance introuvable ou déjà traitée.";
    exit;
}

// Traitement du formulaire
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $decision = $_POST['decision'] ?? '';
    $commentaire = $_POST['commentaire'] ?? '';

    if (!in_array($decision, ['valide', 'rejete'])) {
        $message = "Décision invalide.";
    } else {
        try {
            // Mise à jour du statut de la naissance
            $update = $pdo->prepare("UPDATE naissances SET statut = ? WHERE id = ?");
            $update->execute([$decision, $id]);

            // Création d'un numéro d'enregistrement unique (exemple simple)
            $numero_enregistrement = 'REG-' . strtoupper(bin2hex(random_bytes(4)));

            // Enregistrement dans validations
            $insert = $pdo->prepare("INSERT INTO validations (naissance_id, agent_id, numero_enregistrement, commentaire) VALUES (?, ?, ?, ?)");
            $insert->execute([$id, $agent_id, $numero_enregistrement, $commentaire]);

            $message = "Déclaration {$decision} avec succès.";
        } catch (Exception $e) {
            $message = "Erreur lors de la validation : " . $e->getMessage();
        }
    }
}

?>

<main class="container py-4">

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Connexion - Gestion des Naissances</title>
    <link rel="stylesheet" href="../../assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="../../assets/css/style.css">
</head>
<body>

<?php 
include '../../includes/header.php';
?>
<ul class="navbar-nav" style="margin-left:87%;margin-top:-53px; position: relative;">
    <li class="nav-item">
        <a class="nav-link text-white" href="../../logout.php">Se déconnecter</a>
    </li>
</ul>
<div class="container py-4">
    <h2 class="mb-4">Valider ou rejeter une déclaration de naissance</h2>

    <?php if ($message): ?>
        <div class="alert alert-info"><?= htmlspecialchars($message) ?></div>
    <?php endif; ?>

    <table class="table table-bordered mb-4">
        <tr><th>Nom enfant</th><td><?= htmlspecialchars($naissance['nom_enfant'] . ' ' . $naissance['post_nom_enfant'] . ' ' . $naissance['prenom_enfant']) ?></td></tr>
        <tr><th>Date naissance</th><td><?= htmlspecialchars($naissance['date_naissance']) ?></td></tr>
        <tr><th>Heure naissance</th><td><?= htmlspecialchars($naissance['heure_naissance']) ?></td></tr>
        <tr><th>Sexe</th><td><?= htmlspecialchars($naissance['sexe']) ?></td></tr>
        <tr><th>Père</th><td><?= htmlspecialchars($naissance['pere_nom']) ?></td></tr>
        <tr><th>Mère</th><td><?= htmlspecialchars($naissance['mere_nom']) ?></td></tr>
        <tr><th>Observations</th><td><?= nl2br(htmlspecialchars($naissance['observations'])) ?></td></tr>
    </table>

    <form method="post" class="mb-5">
        <div class="mb-3">
            <label for="decision" class="form-label">Décision</label>
            <select name="decision" id="decision" class="form-select" required>
                <option value="">-- Sélectionner --</option>
                <option value="valide">Valider</option>
                <option value="rejete">Rejeter</option>
            </select>
        </div>
        <div class="mb-3">
            <label for="commentaire" class="form-label">Commentaire (optionnel)</label>
            <textarea name="commentaire" id="commentaire" rows="4" class="form-control"></textarea>
        </div>
        <button type="submit" class="btn btn-success">Soumettre</button>
        <a href="dashboard.php" class="btn btn-secondary">Annuler</a>
    </form>
</div>

    </main>

<?php include '../../includes/footer.php'; ?>
