<?php
require_once '../../config.php';
require_once '../../includes/auth.php';

require_login();
require_role('agent');

// Récupération des naissances
$naissances = $pdo->query("SELECT * FROM naissances ORDER BY date_naissance DESC")->fetchAll();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Liste des Naissances</title>
    <link rel="stylesheet" href="../../assets/bootstrap/css/bootstrap.min.css">
</head>
<body>

<?php include '../../includes/header.php'; ?>

<div class="container py-4">
    <h2 class="mb-4">Liste des Naissances</h2>

    <table class="table table-bordered table-hover">
        <thead class="table-dark">
            <tr>
                <th>Nom de l'enfant</th>
                <th>Date de naissance</th>
                <th>Lieu</th>
                <th>Sexe</th>
                <th>Parents</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($naissances as $n): ?>
            <tr>
                <td><?= $n['nom_enfant'] ?></td>
                <td><?= date('d/m/Y', strtotime($n['date_naissance'])) ?></td>
                <td><?= $n['lieu_naissance'] ?></td>
                <td><?= ucfirst($n['sexe']) ?></td>
                <td><?= $n['nom_pere'] . ' & ' . $n['nom_mere'] ?></td>
                <td>
                    <a href="imprimer_attestation.php?id=<?= $n['id'] ?>" class="btn btn-sm btn-primary" target="_blank">
                        🖨️ Attestation
                    </a>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<?php include '../../includes/footer.php'; ?>
</body>
</html>
