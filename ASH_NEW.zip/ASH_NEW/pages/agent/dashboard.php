<?php

require_once '../../includes/auth.php';
require_once '../../config.php';

// Seulement connecté
require_login();

// Seulement agent
require_role('agent');

// Plusieurs rôles autorisés (exemple : admin ou agent)

// Récupérer les naissances en attente
$stmt = $pdo->prepare("
    SELECT n.*, u.nom AS sage_nom, u.prenom AS sage_prenom
    FROM naissances n
    LEFT JOIN users u ON n.sagefemme_id = u.id
    WHERE n.statut = 'en_attente'
    ORDER BY n.date_declaration DESC
");
$stmt->execute();
$naissances = $stmt->fetchAll();

?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Connexion - Gestion des Naissances</title>
    <link rel="stylesheet" href="../../assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="../../assets/css/style.css">
</head>
<body>

<?php 
include '../../includes/header.php';
?>

<ul class="navbar-nav" style="margin-left:87%;margin-top:-53px; position: relative;">
    <li class="nav-item">
        <a class="nav-link text-white" href="../../logout.php">Se déconnecter</a>
    </li>
</ul>
<main class="container py-4">

<div class="container py-4">
    <h2 class="mb-4">Tableau de bord - Agent de validation</h2>

    <a href="naissances.php" class="btn btn-outline-primary w-100 py-3">
    📋 Voir les Naissances</a>


    <?php if (empty($naissances)): ?>
        <div class="alert alert-info">Aucune déclaration en attente.</div>
    <?php else: ?>
        <div class="table-responsive">
            <table class="table table-bordered table-hover align-middle">
                <thead class="table-dark">
                    <tr>
                        <th>Nom enfant</th>
                        <th>Date déclaration</th>
                        <th>Sage-femme</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($naissances as $n): ?>
                        <tr>
                            <td><?= htmlspecialchars($n['nom_enfant'] . ' ' . $n['post_nom_enfant'] . ' ' . $n['prenom_enfant']) ?></td>
                            <td><?= htmlspecialchars($n['date_declaration']) ?></td>
                            <td><?= htmlspecialchars($n['sage_nom'] . ' ' . $n['sage_prenom']) ?></td>
                            <td>
                                <a href="valider_naissances.php?id=<?= $n['id'] ?>" class="btn btn-sm btn-success">Valider/Rejeter</a>
                                <a href="details_naissance_agent.php?id=<?= $n['id'] ?>" class="btn btn-sm btn-info">Voir détails</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div>
                    </main>
<?php include '../../includes/footer.php'; ?>
