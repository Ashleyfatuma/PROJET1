<?php
// Paramètres de connexion à la base de données
$host = 'localhost';
$dbname = 'gestion_naissance';
$user = 'root'; // ou votre utilisateur MySQL
$pass = '';     // ou votre mot de passe MySQL

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $user, $pass);
} catch (PDOException $e) {
    die("Erreur de connexion à la base de données : " . $e->getMessage());
}
?>
