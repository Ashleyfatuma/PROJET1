<?php
session_start();
session_unset();    // Supprime toutes les variables de session
session_destroy();  // Détruit la session en cours

// Redirection vers la page de login
header('Location:login.php');
exit;
